Please run Generate-figures-and-tables.ipynb with "jupyter" to produce all figures and tables. 
The expected result is shown in "Generate-figures-and-tables-expected-result.html".